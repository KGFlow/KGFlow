# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "3"
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.model.convkb import ConvKB, convkb_ranks
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.dataset.wn18 import WN18Dataset
from KGFlow.utils.sampling_utils import entity_negative_sampling
from KGFlow.metrics.ranks import compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
from KGFlow.metrics.ranks import compute_ranks_by_scores
from tensorflow.keras.layers import Conv1D, Dropout, BatchNormalization, Dense, Conv2D


class ConvKGLayer(tf.keras.Model):
    def __init__(self, num_filters1, num_filters2, activation=tf.nn.relu, drop_rate=0.0, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.conv1 = Conv1D(num_filters1, 2, activation=activation)
        self.conv2 = Conv1D(num_filters2, 2, activation=activation)

        # self.conv_backend1 = Conv1D(num_filters1, 2, activation=activation)
        # self.dense_backend = Dense(num_filters1, activation=activation)
        # self.conv_backend2 = Conv1D(num_filters2, 2, activation=activation)

        # self.activation = activation if activation else lambda x: x
        # self.drop_out = Dropout(drop_rate)
        # self.use_bn = use_bn
        # if self.use_bn:
        #     self.bn1 = BatchNormalization()
        #     self.bn2 = BatchNormalization()
        self.kernel = Dense(1)

    def call(self, inputs, training=None, mask=None):
        """

        :param inputs: [batch_embedded_h, batch_embedded_r, batch_embedded_t]
        :param training:
        :param mask:
        :return: a score Tensor which shape is (batch_size, 1)
        """
        h, r, t = inputs

        f = tf.stack([h, r, t], axis=-2)  # (batch * 3 * dim)
        f = self.conv1(f)
        f = self.conv2(f)
        f = tf.squeeze(f, axis=-2)

        scores = self.kernel(f)

        return -scores  # (batch * 1)


class ConvKG(tf.keras.Model):
    def __init__(self, entity_embeddings, relation_embeddings, num_filters1=64, num_filters2=64, activation=tf.nn.relu,
                 drop_rate=0.0, embedding2constant=False):
        super().__init__()
        self.entity_embeddings = entity_embeddings
        self.relation_embeddings = relation_embeddings
        if embedding2constant:
            self.entity_embeddings = tf.constant(self.entity_embeddings)
            self.relation_embeddings = tf.constant(self.relation_embeddings)

        self.convkg = ConvKGLayer(num_filters1, num_filters2, activation, drop_rate)

    def call(self, inputs, training=None, mask=None, compute_l2_loss=False):
        h_index, r_index, t_index = inputs

        h = tf.nn.embedding_lookup(self.entity_embeddings, h_index)
        r = tf.nn.embedding_lookup(self.relation_embeddings, r_index)
        t = tf.nn.embedding_lookup(self.entity_embeddings, t_index)

        scores = self.convkg([h, r, t], training=training)

        return scores

    def compute_loss(self, scores, labels, activation=tf.nn.softplus, l2_coe=0.0):
        loss = convkg_loss(scores, labels, activation)
        if l2_coe > 0.0:
            loss += tf.add_n([tf.nn.l2_loss(var) for var in self.trainable_variables if
                              "kernel" in var.name or "embedding" in var.name]) * l2_coe
        return loss


def convkg_loss(scores, labels, activation=tf.nn.softplus):
    """
    loss for ConvKG
    :param scores:
    :param labels: pos sample: +1, neg_sample: -1
    :param activation:
    :return: loss, shape: []
    """
    scores = tf.reshape(scores, [-1])
    labels = tf.reshape(tf.cast(labels, dtype=tf.float32), [-1])
    losses = activation(scores * labels)
    return tf.reduce_mean(losses)


def convkg_ranks(batch_h, batch_r, batch_t, num_entities, convkg_model, target_entity_type):
    _batch_size = tf.shape(batch_h)[0]
    if target_entity_type == "tail":
        batch_source = batch_h
        batch_target = batch_t
    else:
        batch_source = batch_t
        batch_target = batch_h

    tiled_s = tf.reshape(tf.tile(tf.expand_dims(batch_source, axis=-1), [1, num_entities]), [-1])
    tiled_r = tf.reshape(tf.tile(tf.expand_dims(batch_r, axis=-1), [1, num_entities]), [-1])
    tiled_o = tf.tile(tf.range(num_entities), [_batch_size])

    if target_entity_type == "tail":
        tiled_indices = [tiled_s, tiled_r, tiled_o]
    else:
        tiled_indices = [tiled_o, tiled_r, tiled_s]

    scores = convkg_model(tiled_indices, training=False)
    scores = tf.reshape(scores, [-1])
    split_size = tf.tile([tf.shape(scores)[0] // _batch_size], [_batch_size])
    scores = tf.stack(tf.split(scores, split_size))

    return compute_ranks_by_scores(scores, batch_target)


# import pickle as pkl
# with open("data/mini_dataset.pkl", "rb") as f:
#     train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = pkl.load(f)

train_kg, test_kg, valid_kg, entity2id, relation2id = WN18Dataset().load_data()
# train_kg, test_kg, valid_kg, entity2id, relation2id = FB15kDataset().load_data()
# train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()

init_embedding = False
num_filters1 = 16
num_filters2 = 16
train_batch_size = 8000
test_batch_size = 10

learning_rate = 1e-3
drop_rate = 0.0
l2_coe = 0.0

optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

if init_embedding:
    # entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    # relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
    entity_embeddings = entity_init_embeddings
    relation_embeddings = relation_init_embeddings
else:
    embedding_size = 32
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()

model = ConvKG(entity_embeddings, relation_embeddings, num_filters1, num_filters2, drop_rate=drop_rate)


class Bilinear(tf.keras.Model):
    """
    Bilinear Model for DGI loss
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.dense = None
        self.bias = tf.Variable(0.0)

    def build(self, input_shapes):
        self.dense = tf.keras.layers.Dense(input_shapes[1][-1], use_bias=False)

    def call(self, inputs, training=None, mask=None, cache=None):
        a, b = inputs
        h = tf.reduce_sum(self.dense(a) * b, axis=-1) + self.bias
        return h


# Bilinear Model for DGI loss
bilinear_model = Bilinear()


def shuffle(x):
    perm_index = np.random.permutation(x.shape[0])
    x = tf.gather(x, perm_index)
    return x


def dgi_loss(E_entity, E_relation, h, r, t):
    pos_E = E_entity
    neg_E = shuffle(E_entity)

    pos_h = tf.gather(pos_E, h)
    pos_t = tf.gather(pos_E, t)
    pos_r = tf.gather(E_relation, r)
    neg_h = tf.gather(neg_E, h)
    neg_t = tf.gather(neg_E, t)

    pos_f = tf.stack([pos_h, pos_r, pos_t], axis=1)
    neg_f = tf.stack([neg_h, pos_r, neg_t], axis=1)

    # positive graph representations
    pos_graph_f = tf.nn.sigmoid(tf.reduce_mean(pos_f, axis=-2, keepdims=True))

    pos_logits = bilinear_model([pos_f, pos_graph_f], training=True)
    neg_logits = bilinear_model([neg_f, pos_graph_f], training=True)
    pos_logits = tf.reshape(pos_logits, [-1])
    neg_logits = tf.reshape(neg_logits, [-1])
    # pos_logits = tf.reduce_sum(pos_logits, axis=-1)
    # neg_logits = tf.reduce_sum(neg_logits, axis=-1)

    pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(
        logits=pos_logits,
        labels=tf.ones_like(pos_logits)
    )

    neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(
        logits=neg_logits,
        labels=tf.zeros_like(neg_logits)
    )

    # DGI loss
    loss = tf.reduce_mean(pos_losses + neg_losses)
    return loss



@tf.function
def forward(batch_indices, training=False):
    return model(batch_indices, training=training)


@tf.function
def compute_loss(pos_scores, neg_scores):
    loss = model.compute_loss(tf.concat([pos_scores, neg_scores], axis=0),
                              tf.concat([tf.ones_like(pos_scores), -tf.ones_like(neg_scores)], axis=0),
                              activation=tf.nn.softplus, l2_coe=l2_coe)
    return loss


compute_ranks = tf.function(convkg_ranks)


for epoch in range(1, 10001):
    for step, (batch_h, batch_r, batch_t) in enumerate(
            tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).
                    shuffle(300000).batch(train_batch_size)):

        with tf.GradientTape() as tape:
            target_entity_type = ["head", "tail"][np.random.randint(0, 2)]
            if target_entity_type == "tail":
                batch_neg_target = entity_negative_sampling(batch_h, batch_r, train_kg, "tail", filtered=False)
                batch_neg_indices = [batch_h, batch_r, batch_neg_target]
            else:
                batch_neg_target = entity_negative_sampling(batch_t, batch_r, train_kg, "head", filtered=False)
                batch_neg_indices = [batch_neg_target, batch_r, batch_t]

            pos_scores = forward([batch_h, batch_r, batch_t], training=True)
            neg_scores = forward(batch_neg_indices, training=True)

            loss = compute_loss(pos_scores, neg_scores)
            loss += dgi_loss(entity_embeddings, relation_embeddings, batch_h, batch_r, batch_t)

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        optimizer.apply_gradients(zip(grads, vars))

    if epoch % 20 == 0:
        print("epoch = {}\tloss = {}".format(epoch, loss))

    if epoch % 200 == 0:

        for target_entity_type in ["head", "tail"]:
            ranks = []
            for (batch_h, batch_r, batch_t) in tf.data.Dataset.from_tensor_slices(
                    (test_kg.h, test_kg.r, test_kg.t)).batch(test_batch_size):
                target_ranks = compute_ranks(batch_h, batch_r, batch_t, test_kg.num_entities, forward, target_entity_type)
                ranks.append(target_ranks)

            ranks = tf.concat(ranks, axis=0)

            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])

            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {}\tMRR = {}\t"
                "Hits@1 = {}\tHits@3 = {}\tHits@10 = {}\tHits@100 = {}\tHits@1000 = {}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_1, hits_3, hits_10, hits_100, hits_1000))
