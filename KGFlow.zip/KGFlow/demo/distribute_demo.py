# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0, 1, 2, 3"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf

global_batch_size = 4 * train_batch_size
strategy = tf.distribute.MirroredStrategy(["GPU:0", "GPU:1", "GPU:2", "GPU:3"])
optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)

loss_object = tf.keras.losses.BinaryCrossentropy(from_logits=True, reduction=tf.keras.losses.Reduction.NONE)

@tf.function
def compute_loss(logits, labels):
    per_loss = loss_object(labels, logits)
    return tf.nn.compute_average_loss(per_loss, global_batch_size=global_batch_size)

with strategy.scope():
    model = Model()

@tf.function
def distributed_train_step(dataset_inputs):
    def train_step(input):

        inputs, labels = input
        with tf.GradientTape() as tape:
            logits = model(inputs)
            loss = compute_loss(logits, labels)

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        optimizer.apply_gradients(zip(grads, vars))
        return loss
    per_replica_losses = strategy.run(train_step, args=(dataset_inputs,))
    return strategy.reduce(tf.distribute.ReduceOp.SUM, per_replica_losses, axis=None)


for epoch in range(1, 100001):
    dataset = tf.data.Dataset.from_tensor_slices((train_data, labels)).shuffle(10000).batch(global_batch_size)
    dist_dataset = strategy.experimental_distribute_dataset(dataset)

    for step, dist_inputs in enumerate(dist_dataset):
        loss = distributed_train_step(dist_inputs)

        if step % 10 == 0:
            print("epoch = {}\tstep = {}\tloss = {:f}".format(epoch, step, loss))

    if epoch % 100 == 0:
        evaluate()
