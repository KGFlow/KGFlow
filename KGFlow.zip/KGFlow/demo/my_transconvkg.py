# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "3"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.model.convkb import ConvKB, convkb_ranks
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.dataset.wn18 import WN18Dataset
from KGFlow.utils.sampling_utils import entity_negative_sampling, EntityNegativeSampler
from KGFlow.metrics.ranks import compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
from KGFlow.metrics.ranks import compute_ranks_by_scores
from tensorflow.keras.layers import Conv1D, Dropout, BatchNormalization, Dense, Conv2D
from KGFlow.utils.rank_utils import get_filter_dict, compute_ranks


class ConvKGLayer(tf.keras.Model):
    def __init__(self, num_filters, activation=tf.nn.tanh, drop_rate=0.0, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.conv_h2t = Conv2D(num_filters, [2, 1], activation=activation)
        self.conv_t2t = Conv2D(num_filters, [2, 1], activation=activation)


    def call(self, inputs, training=None, mask=None):
        """

        :param inputs: [batch_embedded_h, batch_embedded_r, batch_embedded_t]
        :param training:
        :param mask:
        :return: a score Tensor which shape is (batch_size, 1)
        """
        h, r, t = inputs

        f = tf.stack([h, r, t], axis=-2)  # [batch, 3, dim]
        f = tf.expand_dims(f, axis=-1)  # [batch, 3, dim, 1]
        h2t = self.conv_h2t(f)  # [batch, 2, dim, num_filters]
        h2t = tf.reshape(h2t, [tf.shape(h2t)[0], tf.shape(h2t)[1], -1])
        f = tf.stack([t, r, h], axis=-2)
        f = tf.expand_dims(f, axis=-1)
        t2t = self.conv_t2t(f)  # [batch, 2, dim, num_filters]
        t2t = tf.reshape(t2t, [tf.shape(t2t)[0], tf.shape(t2t)[1], -1])

        # scores = -tf.reduce_sum(tf.reduce_sum(h2t * t2t, axis=-1), axis=-1, keepdims=True)  # [batch, 1]

        h2t = tf.transpose(h2t, [1, 0, 2])
        t2t = tf.transpose(t2t, [1, 2, 0])

        matrix = tf.matmul(h2t, t2t)
        labels = tf.stack([tf.eye(tf.shape(h)[0]), tf.eye(tf.shape(h)[0])])
        losses = tf.nn.softmax_cross_entropy_with_logits(
            labels=labels,
            logits=matrix
        )

        loss = tf.reduce_mean(losses)

        return loss

    def forward(self, inputs):
        h, r, t = inputs

        f = tf.stack([h, r, t], axis=-2)  # [batch, 3, dim]
        f = tf.expand_dims(f, axis=-1)  # [batch, 3, dim, 1]
        h2t = self.conv_h2t(f)  # [batch, 2, dim, num_filters]
        h2t = tf.reshape(h2t, [tf.shape(h2t)[0], tf.shape(h2t)[1], -1])
        f = tf.stack([t, r, h], axis=-2)
        f = tf.expand_dims(f, axis=-1)
        t2t = self.conv_t2t(f)  # [batch, 2, dim, num_filters]
        t2t = tf.reshape(t2t, [tf.shape(t2t)[0], tf.shape(t2t)[1], -1])

        scores = -tf.reduce_mean(tf.reduce_sum(h2t * t2t, axis=-1), axis=-1, keepdims=True)  # [batch, 1]
        return scores

# class ConvKGLayer(tf.keras.Model):
#     def __init__(self, num_filters, activation=tf.nn.tanh, drop_rate=0.0, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         self.conv_h2t = Conv1D(num_filters, 2, activation=activation)
#         self.dense_t2t = Dense(num_filters, activation=activation)
#
#     def call(self, inputs, training=None, mask=None):
#         """
#
#         :param inputs: [batch_embedded_h, batch_embedded_r, batch_embedded_t]
#         :param training:
#         :param mask:
#         :return: a score Tensor which shape is (batch_size, 1)
#         """
#         h, r, t = inputs
#
#         f = tf.stack([h, r, t], axis=-2)  # [batch, 3, dim]
#         h2t = self.conv_h2t(f)  # [batch, 2, num_filters]
#
#         f = tf.stack([t, h], axis=-2)
#         t2t = self.dense_t2t(f)  # [batch, 2, num_filters]
#
#         # scores = -tf.reduce_sum(tf.reduce_sum(h2t * t2t, axis=-1), axis=-1, keepdims=True)  # [batch, 1]
#
#         h2t = tf.transpose(h2t, [1, 0, 2])
#         t2t = tf.transpose(t2t, [1, 2, 0])
#
#         matrix = tf.matmul(h2t, t2t)
#         labels = tf.stack([tf.eye(tf.shape(h)[0]), tf.eye(tf.shape(h)[0])])
#         losses = tf.nn.softmax_cross_entropy_with_logits(
#             labels=labels,
#             logits=matrix
#         )
#
#         loss = tf.reduce_mean(losses)
#
#         return loss
#
#     def forward(self, inputs):
#         h, r, t = inputs
#
#         f = tf.stack([h, r, t], axis=-2)  # [batch, 3, dim]
#         h2t = self.conv_h2t(f)  # [batch, 2, num_filters]
#
#         f = tf.stack([t, h], axis=-2)
#         t2t = self.dense_t2t(f)  # [batch, 2, num_filters]
#
#         scores = -tf.reduce_mean(tf.reduce_sum(h2t * t2t, axis=-1), axis=-1, keepdims=True)  # [batch, 1]
#         return scores



#
# class ConvKGLayer(tf.keras.Model):
#     def __init__(self, num_filters, activation=tf.nn.leaky_relu, drop_rate=0.0, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         # self.conv_h2t = Conv2D(num_filters, [2, 1], activation=activation)
#         # self.conv_t2t = Conv2D(num_filters, [2, 1], activation=activation)
#
#     def call(self, inputs, training=None, mask=None):
#         """
#
#         :param inputs: [batch_embedded_h, batch_embedded_r, batch_embedded_t]
#         :param training:
#         :param mask:
#         :return: a score Tensor which shape is (batch_size, 1)
#         """
#         h, r, t = inputs
#
#         # f = tf.stack([h, r, t], axis=-2)  # [batch, 3, dim]
#         # f = tf.expand_dims(f, axis=-1)  # [batch, 3, dim, 1]
#         # h2t = self.conv_h2t(f)  # [batch, 2, dim, num_filters]
#         # h2t = tf.reshape(h2t, [tf.shape(h2t)[0], tf.shape(h2t)[1], -1])
#         # f = tf.stack([t, r, h], axis=-2)
#         # f = tf.expand_dims(f, axis=-1)
#         # t2t = self.conv_t2t(f)  # [batch, 2, dim, num_filters]
#         # t2t = tf.reshape(t2t, [tf.shape(t2t)[0], tf.shape(t2t)[1], -1])
#         #
#         # # scores = -tf.reduce_sum(tf.reduce_sum(h2t * t2t, axis=-1), axis=-1, keepdims=True)  # [batch, 1]
#         #
#         # h2t = tf.transpose(h2t, [1, 0, 2])
#         # t2t = tf.transpose(t2t, [1, 2, 0])
#
#         tt = h + r
#         hh = t - r
#
#         h2t = tf.stack([hh, tt])
#         t2t = tf.stack([h, t])
#
#         matrix = tf.matmul(h2t, t2t, transpose_b=True)
#         labels = tf.stack([tf.eye(tf.shape(h)[0]), tf.eye(tf.shape(h)[0])])
#         losses = tf.nn.softmax_cross_entropy_with_logits(
#             labels=labels,
#             logits=matrix
#         )
#
#         loss = tf.reduce_mean(losses)
#
#         return loss
#
#     def forward(self, inputs):
#         h, r, t = inputs
#
#         # f = tf.stack([h, r, t], axis=-2)  # [batch, 3, dim]
#         # f = tf.expand_dims(f, axis=-1)  # [batch, 3, dim, 1]
#         # h2t = self.conv_h2t(f)  # [batch, 2, dim, num_filters]
#         # h2t = tf.reshape(h2t, [tf.shape(h2t)[0], tf.shape(h2t)[1], -1])
#         # f = tf.stack([t, r, h], axis=-2)
#         # f = tf.expand_dims(f, axis=-1)
#         # t2t = self.conv_t2t(f)  # [batch, 2, dim, num_filters]
#         # t2t = tf.reshape(t2t, [tf.shape(t2t)[0], tf.shape(t2t)[1], -1])
#         tt = h + r
#         hh = t - r
#
#         scores = -tf.reduce_sum(hh * h + tt * t, axis=-1, keepdims=True)  # [batch, 1]
#         return scores
#

#
# class ConvKG(tf.keras.Model):
#     def __init__(self, entity_embeddings, relation_embeddings, num_filters=10, activation=tf.nn.leaky_relu,
#                  drop_rate=0.0):
#         super().__init__()
#         self.entity_embeddings = entity_embeddings
#         self.relation_embeddings = relation_embeddings
#
#         self.convkg = ConvKGLayer(num_filters, activation, drop_rate)
#
#     def call(self, inputs, training=None, mask=None, compute_l2_loss=False):
#         h_index, r_index, t_index = inputs[0], inputs[1], inputs[2]
#
#         h = tf.nn.embedding_lookup(self.entity_embeddings, h_index)
#         r = tf.nn.embedding_lookup(self.relation_embeddings, r_index)
#         t = tf.nn.embedding_lookup(self.entity_embeddings, t_index)
#
#         scores = self.convkg([h, r, t], training=training)
#
#         return scores
#
#     def compute_loss(self, scores, labels, activation=tf.nn.softplus, l2_coe=0.0):
#         loss = convkg_loss(scores, labels, activation)
#         if l2_coe > 0.0:
#             loss += tf.add_n([tf.nn.l2_loss(var) for var in self.trainable_variables if
#                               "kernel" in var.name or "embedding" in var.name]) * l2_coe
#         return loss
#
#
# def convkg_loss(scores, labels, activation=tf.nn.softplus):
#     """
#     loss for ConvKG
#     :param scores:
#     :param labels: pos sample: +1, neg_sample: -1
#     :param activation:
#     :return: loss, shape: []
#     """
#     scores = tf.reshape(scores, [-1])
#     labels = tf.reshape(tf.cast(labels, dtype=tf.float32), [-1])
#     losses = activation(scores * labels)
#     # losses = tf.nn.sigmoid_cross_entropy_with_logits(labels=labels, logits=scores)
#     return tf.reduce_mean(losses)
#

# train_kg, test_kg, valid_kg, entity2id, relation2id = WN18Dataset().load_data()
# train_kg, test_kg, valid_kg, entity2id, relation2id = FB15kDataset().load_data()
train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()

init_embedding = True
train_filtered = False
num_neg = 10
num_filters = 64
# train_n_batch = 100
# train_batch_size = train_kg.num_triples // train_n_batch
train_batch_size = 200
test_batch_size = 1

filter = True
filter_dict = get_filter_dict(test_kg, [train_kg, valid_kg]) if filter else None

learning_rate = 1e-3
drop_rate = 0.0
l2_coe = 1e-2

optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

if init_embedding:
    entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
else:
    embedding_size = 32
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()

# model = ConvKG(entity_embeddings, relation_embeddings, num_filters, drop_rate=drop_rate)
model = ConvKGLayer(num_filters)
sampler = EntityNegativeSampler(train_kg)

# class Bilinear(tf.keras.Model):
#     """
#     Bilinear Model for DGI loss
#     """
#
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#
#         self.dense = None
#         self.bias = tf.Variable(0.0)
#
#     def build(self, input_shapes):
#         self.dense = tf.keras.layers.Dense(input_shapes[1][-1], use_bias=False)
#
#     def call(self, inputs, training=None, mask=None, cache=None):
#         a, b = inputs
#         h = tf.reduce_sum(self.dense(a) * b, axis=-1) + self.bias
#         return h
#
#
# # Bilinear Model for DGI loss
# bilinear_model = Bilinear()
#
#
# def shuffle(x):
#     perm_index = np.random.permutation(x.shape[0])
#     x = tf.gather(x, perm_index)
#     return x
#
#
# def dgi_loss(E_entity, E_relation, h, r, t):
#     pos_E = E_entity
#     neg_E = shuffle(E_entity)
#
#     pos_h = tf.gather(pos_E, h)
#     pos_t = tf.gather(pos_E, t)
#     pos_r = tf.gather(E_relation, r)
#     neg_h = tf.gather(neg_E, h)
#     neg_t = tf.gather(neg_E, t)
#
#     pos_f = tf.stack([pos_h, pos_r, pos_t], axis=1)
#     neg_f = tf.stack([neg_h, pos_r, neg_t], axis=1)
#
#     # positive graph representations
#     pos_graph_f = tf.nn.sigmoid(tf.reduce_mean(pos_f, axis=-2, keepdims=True))
#
#     pos_logits = bilinear_model([pos_f, pos_graph_f], training=True)
#     neg_logits = bilinear_model([neg_f, pos_graph_f], training=True)
#     pos_logits = tf.reshape(pos_logits, [-1])
#     neg_logits = tf.reshape(neg_logits, [-1])
#     # pos_logits = tf.reduce_sum(pos_logits, axis=-1)
#     # neg_logits = tf.reduce_sum(neg_logits, axis=-1)
#
#     pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(
#         logits=pos_logits,
#         labels=tf.ones_like(pos_logits)
#     )
#
#     neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(
#         logits=neg_logits,
#         labels=tf.zeros_like(neg_logits)
#     )
#
#     # DGI loss
#     loss = tf.reduce_mean(pos_losses + neg_losses)
#     return loss


# def encode(E_entity):
#     h_index, r_index, t_index = train_kg.graph_indices
#     h = tf.nn.embedding_lookup(E_entity, h_index)
#     t = tf.nn.embedding_lookup(E_entity, t_index)
#     r = t - h
#     E_r = tf.math.unsorted_segment_mean(r, r_index, train_kg.num_relations)
#
#     rr = tf.nn.embedding_lookup(E_r, r_index)
#     tt = h + rr
#     hh = t - rr
#
#     E_e = tf.math.unsorted_segment_mean(tf.concat([hh, tt], axis=0),
#                                         tf.concat([h_index, t_index], axis=0), train_kg.num_entities)
#
#     return E_e, E_r


# @tf.function
def forward(E_e, E_r, batch_indices):
    h_index, r_index, t_index = batch_indices[0], batch_indices[1], batch_indices[2]

    h = tf.nn.embedding_lookup(E_e, h_index)
    r = tf.nn.embedding_lookup(E_r, r_index)
    t = tf.nn.embedding_lookup(E_e, t_index)

    scores = model.forward([h, r, t])
    return scores


# @tf.function
def compute_loss(E_e, E_r, batch_indices, training=False):
    h_index, r_index, t_index = batch_indices[0], batch_indices[1], batch_indices[2]

    h = tf.nn.embedding_lookup(E_e, h_index)
    r = tf.nn.embedding_lookup(E_r, r_index)
    t = tf.nn.embedding_lookup(E_e, t_index)

    loss = model([h, r, t], training=training)
    loss += (tf.add_n([tf.nn.l2_loss(var) for var in model.trainable_variables if "kernel" in var.name]) + tf.reduce_mean(h**2 + r**2 + t**2)) * l2_coe
    return loss


# @tf.function
# def compute_loss(pos_scores, neg_scores):
#     # loss = model.compute_loss(tf.concat([pos_scores, neg_scores], axis=0),
#     #                           tf.concat([tf.ones_like(pos_scores), -tf.ones_like(neg_scores)], axis=0),
#     #                           activation=tf.nn.softplus, l2_coe=l2_coe)
#
#     pos_loss = convkg_loss(pos_scores, tf.ones_like(pos_scores), activation=tf.nn.softplus)
#     neg_loss = convkg_loss(neg_scores, -tf.ones_like(neg_scores), activation=tf.nn.softplus)
#
#     # pos_loss = model.compute_loss(pos_scores, tf.zeros_like(pos_scores), activation=tf.nn.softplus)
#     # neg_loss = model.compute_loss(neg_scores, tf.ones_like(neg_scores), activation=tf.nn.softplus)
#     #
#     loss = pos_loss + neg_loss
#
#     # pos_scores = tf.tile(pos_scores, [2*num_neg, 1])
#     # # losses = tf.math.maximum(0.0, pos_scores - neg_scores)
#     # losses = tf.maximum(margin + pos_scores - neg_scores, 0.0)
#     # loss = tf.reduce_mean(losses)
#
#     return loss



for epoch in range(1, 10001):
    for step, (batch_h, batch_r, batch_t) in enumerate(
            tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).
                    shuffle(300000).batch(train_batch_size)):

        with tf.GradientTape() as tape:

            # batch_neg_indices = sampler.indices_sampling(batch_h, batch_r, batch_t, num_neg=num_neg,
            #                                              filtered=train_filtered)

            # E_e, E_r = encode(entity_embeddings)

            loss = compute_loss(entity_embeddings, relation_embeddings, [batch_h, batch_r, batch_t], training=True)
            # neg_scores = forward(entity_embeddings, relation_embeddings, batch_neg_indices, training=True)

            # loss = compute_loss(pos_scores, neg_scores)

            # l2_loss = tf.add_n([tf.nn.l2_loss(var) for var in tape.watched_variables() if "kernel" in var.name or "embedding" in var.name])
            # l2_loss *= l2_coe
            # loss += l2_loss
            # l2_loss = tf.add_n([tf.nn.l2_loss(var) for var in tape.watched_variables() if "kernel" in var.name])
            # l2_loss += tf.add_n([tf.reduce_mean(tf.gather(entity_embeddings, batch_h) ** 2),
            #                      tf.reduce_mean(tf.gather(relation_embeddings, batch_r) ** 2),
            #                      tf.reduce_mean(tf.gather(entity_embeddings, batch_t)) ** 2])
            # l2_loss *= l2_coe
            # loss += l2_loss

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        grads, _ = tf.clip_by_global_norm(grads, 0.5)
        optimizer.apply_gradients(zip(grads, vars))

        if step % 100 == 0:
            print("epoch = {}\tstep = {}\tloss = {}".format(epoch, step, loss))

    if epoch % 20 == 0:

        for target_entity_type in ["head", "tail"]:
            ranks = compute_ranks(test_kg, lambda x: forward(entity_embeddings, relation_embeddings, x), target_entity_type, test_batch_size,
                                  filter_dict)
            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            # hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])
            hits_1, hits_10, hits_100 = compute_hits(ranks, [1, 10, 100])
            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {:f}\tMRR = {:f}\t"
                "Hits@10 = {:f}\tHits@1 = {:f}\tHits@100 = {:f}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_10, hits_1, hits_100))
