# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow import keras
import numpy as np
from KGFlow.nn import aggregate_neighbors, gcn_mapper, identity_updater, sum_reducer
from KGFlow.nn.kernel.segment import segment_softmax
import KGFlow as kgf
from KGFlow.model.transe import TransE, compute_distance, transe_ranks
from KGFlow.model.convkb import ConvKB, ConvKBLayer, convkb_loss
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.utils.rank_utils import get_filter_dict, compute_ranks
from KGFlow.utils.sampling_utils import entity_negative_sampling, EntityNegativeSampler
from KGFlow.metrics.ranks import compute_ranks_by_scores, compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
import pickle as pkl


# with open("data/mini_dataset_reverse.pkl", "rb") as f:
#     train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = pkl.load(f)

# train_kg, test_kg, valid_kg, entity2id, relation2id = FB15kDataset().load_data()
train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()

h = np.concatenate([train_kg.h, train_kg.t], axis=-1)
r = np.concatenate([train_kg.r, train_kg.r+237], axis=-1)
t = np.concatenate([train_kg.t, train_kg.h], axis=-1)
train_kg = kgf.KG(h, r, t, entity2id, relation2id)


num_entities = len(entity2id)
num_relations = len(relation2id)
print(train_kg, test_kg, valid_kg)

init_embedding = False
units_list = [10, 10]

drop_rate = 0.5
l2_coe = 1e-3

train_n_batch = 100
train_batch_size = train_kg.num_triples // train_n_batch
test_batch_size = 10
learning_rate = 1e-2

num_filters = 5
num_neg = 5
train_filtered = False
use_bn = False

filter = True
filter_dict = get_filter_dict(test_kg, [train_kg, valid_kg]) if filter else None


if init_embedding:
    entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
else:
    embedding_size = 20
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()


class GAT(keras.Model):

    def __init__(self, units, activation=None, att_activation=tf.nn.leaky_relu, relation_activation=None,
                 drop_rate=0.0, use_bias=True, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.units = units
        self.activation = activation if activation else lambda x: x

        self.att_activation = att_activation if att_activation else lambda x: x

        self.h_kernel = tf.keras.layers.Dense(units=1, activation=self.att_activation)
        self.r_kernel = tf.keras.layers.Dense(units=1, activation=self.att_activation)
        self.t_kernel = tf.keras.layers.Dense(units=1, activation=self.att_activation)

        self.kernel = tf.keras.layers.Dense(units=self.units, use_bias=False)
        self.res_kernel = tf.keras.layers.Dense(units=self.units, use_bias=False)
        self.relation_kernel = tf.keras.layers.Dense(units=self.units, activation=relation_activation)

        self.dropout = tf.keras.layers.Dropout(drop_rate)

        self.use_bias = use_bias
        if self.use_bias:
            self.bias = self.add_weight("bias", shape=[self.units], initializer="zeros")

    def call(self, inputs, training=None, mask=None):
        """

        :param inputs: [(h, r, t), entity_embeddings, relation_embeddings]
        :param training:
        :param mask:
        :return:
        """

        (h_index, r_index, t_index), entity_embeddings, relation_embeddings = inputs
        num_entities = tf.shape(entity_embeddings)[0]

        H = tf.gather(self.h_kernel(entity_embeddings), h_index, axis=0)
        R = tf.gather(self.r_kernel(relation_embeddings), r_index, axis=0)
        T = tf.gather(self.t_kernel(entity_embeddings), t_index, axis=0)

        V = self.kernel(entity_embeddings)

        scale = tf.math.sqrt(tf.cast(tf.shape(H)[-1], tf.float32))
        att_score = tf.reduce_sum(H * R * T / scale, axis=-1)

        normed_att_score = segment_softmax(att_score, h_index, num_entities)
        normed_att_score = self.dropout(normed_att_score, training=training)

        f = aggregate_neighbors(
            V, (h_index, t_index), normed_att_score,
            gcn_mapper,
            sum_reducer,
            identity_updater
        )

        if self.use_bias:
            f += self.bias
        f = self.activation(f)
        f += self.res_kernel(entity_embeddings)

        E_relation = self.relation_kernel(relation_embeddings // 2)
        E_relation = tf.concat([E_relation, -E_relation], axis=0)
        return f, E_relation


class GATModel(keras.Model):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.entity_embeddings = entity_embeddings
        self.relation_embeddings = tf.concat([relation_embeddings, -relation_embeddings], axis=0)

        self.gat0 = GAT(units=units_list[0], activation=tf.nn.relu, att_activation=tf.nn.relu, relation_activation=tf.nn.relu,
                        drop_rate=0.0, use_bias=True)
        self.gat1 = GAT(units=units_list[1], activation=None, att_activation=tf.nn.relu,
                        drop_rate=0.0, use_bias=True)
        self.dense = keras.layers.Dense(units_list[-1])
        self.relation_dense = keras.layers.Dense(units_list[-1])
        self.dropout = tf.keras.layers.Dropout(drop_rate)

    def call(self, inputs, training=None, mask=None):
        h_index, r_index, t_index = inputs[0], inputs[1], inputs[2]

        E_entity = self.entity_embeddings
        E_relation = self.relation_embeddings
        # E_relation = self.relation_dense(E_relation)

        E_entity = self.dropout(E_entity, training=training)
        entity_features, E_relation = self.gat0([(h_index, r_index, t_index), E_entity, E_relation], training=training)

        entity_features = self.dropout(entity_features, training=training)
        entity_features, E_relation = self.gat1([(h_index, r_index, t_index), entity_features, E_relation], training=training)

        entity_features += self.dense(E_entity)

        return entity_features, E_relation


model = GATModel()

convkb_model = ConvKBLayer(num_filters, 1, tf.nn.relu, drop_rate, use_bn)
# convkb_model = ConvKB(entity_embeddings, relation_embeddings, num_filters, drop_rate=drop_rate, use_bn=use_bn)
sampler = EntityNegativeSampler(train_kg)

@tf.function
def encode(indices, training=False):
    return model(inputs=indices, training=training)


@tf.function
def decode(indices, E_entity, E_relation, training=False):
    h_index, r_index, t_index = indices[0], indices[1], indices[2]
    h = tf.nn.embedding_lookup(E_entity, h_index)
    r = tf.nn.embedding_lookup(E_relation, r_index)
    t = tf.nn.embedding_lookup(E_entity, t_index)
    scores = convkb_model([h, r, t], training=training)
    return scores


@tf.function
def compute_loss(pos_scores, neg_scores):
    # pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(tf.zeros_like(pos_scores), pos_scores)
    # neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(tf.ones_like(neg_scores), neg_scores)
    # pos_loss = tf.reduce_mean(pos_losses)
    # neg_loss = tf.reduce_mean(neg_losses)
    pos_loss = convkb_loss(pos_scores, tf.ones_like(pos_scores), activation=tf.nn.softplus)
    neg_loss = convkb_loss(neg_scores, -tf.ones_like(neg_scores), activation=tf.nn.softplus)

    loss = pos_loss + neg_loss
    return loss


optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

for epoch in range(1, 100001):

    with tf.GradientTape() as tape:

        E_entity, E_relation = encode(train_kg.graph_indices, training=True)

        neg_indices = sampler.indices_sampling(train_kg.h, train_kg.r, train_kg.t, num_neg=num_neg,
                                               filtered=train_filtered)

        pos_scores = decode([train_kg.h, train_kg.r, train_kg.t], E_entity, E_relation, training=True)
        neg_scores = decode(neg_indices, E_entity, E_relation, training=True)

        # pos_scores, neg_scores = [], []
        # for batch_h, batch_r, batch_t in tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).batch(train_batch_size):
        #     batch_pos_indices = [batch_h, batch_r, batch_t]
        #     batch_neg_indices = sampler.indices_sampling(batch_h, batch_r, batch_t, num_neg=num_neg,
        #                                                  filtered=train_filtered)
        #     batch_pos_scores = decode(batch_pos_indices, training=True)
        #     batch_neg_scores = decode(batch_neg_indices, training=True)
        #     pos_scores.append(batch_pos_scores)
        #     neg_scores.append(batch_neg_scores)
        #
        # pos_scores = tf.concat(pos_scores, axis=0)
        # neg_scores = tf.concat(neg_scores, axis=0)
        loss = compute_loss(pos_scores, neg_scores)

        # kernel_vals = [var for var in tape.watched_variables() if "kernel" in var.name or "embedding" in var.name]
        # l2_losses = [tf.nn.l2_loss(kernel_var) for kernel_var in kernel_vals]
        # loss += tf.add_n(l2_losses) * l2_coe

    vars = tape.watched_variables()
    grads = tape.gradient(loss, vars)
    optimizer.apply_gradients(zip(grads, vars))

    if epoch % 1 == 0:
        print("epoch = {}\tloss = {}".format(epoch, loss))


    if epoch % 20 == 0:

        for target_entity_type in ["head", "tail"]:
            ranks = compute_ranks(test_kg, lambda indices: decode(indices, E_entity, E_relation), target_entity_type, test_batch_size, filter_dict)

            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            # hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])
            hits_1, hits_10, hits_100 = compute_hits(ranks, [1, 10, 100])
            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {:f}\tMRR = {:f}\t"
                "Hits@10 = {:f}\tHits@1 = {:f}\tHits@100 = {:f}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_10, hits_1, hits_100))
