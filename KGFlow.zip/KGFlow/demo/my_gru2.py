# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "4"
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.model.convkb import convkb_ranks
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.dataset.wn18 import WN18Dataset
from KGFlow.utils.sampling_utils import entity_negative_sampling
from KGFlow.metrics.ranks import compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
import pickle as pkl


# with open("data/mini_dataset.pkl", "rb") as f:
#     train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = pkl.load(f)

# train_kg, test_kg, valid_kg, entity2id, relation2id = FB15kDataset().load_data()

# train_kg, test_kg, valid_kg, entity2id, relation2id = WN18Dataset().load_data()
train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()

print(train_kg, test_kg, valid_kg)

init_embedding = True
train_batch_size = 8000
test_batch_size = 10

learning_rate = 1e-2
drop_rate = 0.0
l2_coe = 0.0

optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

if init_embedding:
    entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
else:
    embedding_size = 32
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()


gru = tf.keras.layers.GRU(16)
out_layer = tf.keras.layers.Dense(1)
IS = tf.zeros((1, entity_embeddings.shape[-1]))
IS = tf.Variable(IS)


@tf.function
def encode(h_index, r_index, t_index):
    h = tf.nn.embedding_lookup(entity_embeddings, h_index)
    r = tf.nn.embedding_lookup(relation_embeddings, r_index)
    t = tf.nn.embedding_lookup(entity_embeddings, t_index)
    tiled_IS = tf.tile(IS, [tf.shape(h_index)[0], 1])

    forward = tf.stack([h, r, tiled_IS, t], axis=-2)
    backend = tf.stack([t, tiled_IS, h, r], axis=-2)

    forward = gru(forward)
    backend = gru(backend)

    # forward = tf.nn.l2_normalize(forward)
    # backend = tf.nn.l2_normalize(backend)

    return [forward, backend]


@tf.function
def pred(fb):
    return out_layer(tf.add_n(fb))


@tf.function
def model(indices):
    h, r, t = indices
    fb = encode(h, r, t)
    return pred(fb)


def compute_distance(a, b, norm=1):
    if norm == 1:
        return tf.reduce_sum(tf.math.abs(a - b), axis=-1)
    if norm == 2:
        return tf.reduce_sum(tf.math.square(a - b), axis=-1)
    if norm == -1:
        return -tf.reduce_sum(a * b, axis=-1)


@tf.function
def compute_dis_loss(pos, neg, norm=1):
    dis1 = compute_distance(pos[0], pos[1], norm)  # dis -> 0
    dis2 = compute_distance(neg[0], neg[1], norm)  # dis -> 0
    dis3 = compute_distance(pos[0], neg[0], norm)  # dis -> +
    dis4 = compute_distance(pos[1], neg[1], norm)  # dis -> +
    loss = tf.nn.sigmoid_cross_entropy_with_logits(
        logits=tf.concat([dis1, dis2, dis3, dis4], axis=0),
        labels=tf.concat([tf.zeros_like(dis1), tf.zeros_like(dis2), tf.ones_like(dis3), tf.ones_like(dis4)], axis=0)
    )
    return tf.reduce_mean(loss)


@tf.function
def compute_pred_loss(pos, neg):
    p = pred(pos)
    n = pred(neg)
    loss = tf.nn.sigmoid_cross_entropy_with_logits(
        logits=tf.concat([p, n], axis=0),
        labels=tf.concat([tf.zeros_like(p), tf.ones_like(n)], axis=0)
    )
    return tf.reduce_mean(loss)


compute_ranks = tf.function(convkb_ranks)


for epoch in range(1, 10001):
    for step, (batch_h, batch_r, batch_t) in enumerate(
            tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).
                    shuffle(200000).batch(train_batch_size)):

        with tf.GradientTape() as tape:
            target_entity_type = ["head", "tail"][np.random.randint(0, 2)]
            if target_entity_type == "tail":
                batch_neg_target = entity_negative_sampling(batch_h, batch_r, train_kg, "tail", filtered=False)
                batch_neg_indices = [batch_h, batch_r, batch_neg_target]
            else:
                batch_neg_target = entity_negative_sampling(batch_t, batch_r, train_kg, "head", filtered=False)
                batch_neg_indices = [batch_neg_target, batch_r, batch_t]

            pos = encode(batch_h, batch_r, batch_t)
            neg = encode(*batch_neg_indices)

            pred_loss = compute_pred_loss(pos, neg)
            dis_loss = compute_dis_loss(pos, neg)
            loss = pred_loss + dis_loss

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        optimizer.apply_gradients(zip(grads, vars))

    if epoch % 20 == 0:
        print("epoch = {}\tpred_loss = {}\tdis_loss = {}".format(epoch, pred_loss, dis_loss))

    if epoch % 200 == 0:

        for target_entity_type in ["head", "tail"]:
            ranks = []
            for (batch_h, batch_r, batch_t) in tf.data.Dataset.from_tensor_slices(
                    (test_kg.h, test_kg.r, test_kg.t)).batch(test_batch_size):
                target_ranks = compute_ranks(batch_h, batch_r, batch_t, test_kg.num_entities, model, target_entity_type)
                ranks.append(target_ranks)

            ranks = tf.concat(ranks, axis=0)

            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])

            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {}\tMRR = {}\t"
                "Hits@1 = {}\tHits@3 = {}\tHits@10 = {}\tHits@100 = {}\tHits@1000 = {}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_1, hits_3, hits_10, hits_100, hits_1000))
