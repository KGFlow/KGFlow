# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.dataset.wn18 import WN18Dataset, WN18RRDataset
from KGFlow.dataset.fb15k import FB15k237Dataset
import pickle as pkl

# train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()
#
# n_entity = 1000
# entity2id = {k: v for k, v in entity2id.items() if v < n_entity}
#
# data = []
# for kg in [train_kg, test_kg, valid_kg]:
#     triples = np.array([[h, r, t] for h, r, t in kg.graph_triples if h < n_entity and t < n_entity])
#     mini_kg = kgf.KG(triples[:, 0], triples[:, 1], triples[:, 2], entity2id, relation2id)
#     data.append(mini_kg)
#
# data.extend([entity2id, relation2id, entity_init_embeddings[:n_entity], relation_init_embeddings])
#
# with open("data/mini_dataset.pkl", "wb") as f:
#     pkl.dump(data, f)

with open("data/mini_dataset.pkl", "rb") as f:
    train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = pkl.load(f)

n_relation = len(relation2id)
for k, v in list(relation2id.items()):
    relation2id[k + " reverse"] = v + n_relation
relation_init_embeddings = np.concatenate([relation_init_embeddings, -relation_init_embeddings], axis=0)

h, r, t = train_kg.graph_indices
hh = np.concatenate([h, t], axis=0)
tt = np.concatenate([t, h], axis=0)
rr = np.concatenate([r, r+n_relation], axis=0)
train_kg = kgf.KG(hh, rr, tt, entity2id, relation2id)

with open("data/mini_dataset_reverse.pkl", "wb") as f:
    pkl.dump([train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings], f)