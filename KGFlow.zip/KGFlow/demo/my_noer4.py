# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "4"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.model.convkb import ConvKB, convkb_ranks, ConvKBLayer, convkb_loss
from KGFlow.model.transe import transe_ranks, compute_distance, transe_loss, TransE
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.dataset.wn18 import WN18Dataset
from KGFlow.metrics.ranks import compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
from KGFlow.metrics.ranks import compute_ranks_by_scores
from KGFlow.utils.rank_utils import get_filter_dict
from KGFlow.utils.sampling_utils import entity_negative_sampling, EntityNegativeSampler
from tensorflow.keras.layers import Conv1D, Dropout, BatchNormalization, Dense, Conv2D


train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()


init_embedding = True
num_filters = 5

drop_rate = 0.5
l2_coe = 0.0

train_n_batch = 100
train_batch_size = train_kg.num_triples // train_n_batch
test_batch_size = 10
learning_rate = 1e-2

margin = 2.0
distance_norm = 1

num_neg = 10
train_filtered = False
use_bn = False

filter = True
filter_dict = get_filter_dict(test_kg, [train_kg, valid_kg]) if filter else None


optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

if init_embedding:
    entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
else:
    embedding_size = 32
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()


# model = ConvKBLayer(num_filters, activation=tf.nn.relu, drop_rate=drop_rate)
# sampler = EntityNegativeSampler(train_kg)


# def shuffle(x):
#     perm_index = np.random.permutation(x.shape[0])
#     x = tf.gather(x, perm_index)
#     return x


def encode(E_entity):
    h_index, r_index, t_index = train_kg.graph_indices
    h = tf.nn.embedding_lookup(E_entity, h_index)
    t = tf.nn.embedding_lookup(E_entity, t_index)
    r = t - h
    E_relation = tf.math.unsorted_segment_mean(r, r_index, train_kg.num_relations)

    rr = tf.nn.embedding_lookup(E_relation, r_index)
    tt = h + rr
    hh = t - rr

    E_entity = tf.math.unsorted_segment_mean(tf.concat([hh, tt], axis=0),
                                             tf.concat([h_index, t_index], axis=0), train_kg.num_entities)
    # E_t = tf.math.unsorted_segment_mean(tt, t_index, train_kg.num_entities)
    #
    # E = E_h + E_t

    # pos_logits = bilinear_model([E, E_entity], training=True)
    # neg_logits = bilinear_model([shuffle(E_entity), E_entity], training=True)
    #
    # pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(
    #     logits=pos_logits,
    #     labels=tf.ones_like(pos_logits)
    # )
    #
    # neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(
    #     logits=neg_logits,
    #     labels=tf.zeros_like(neg_logits)
    # )
    #
    # # DGI loss
    # dgi_loss = tf.reduce_mean(pos_losses + neg_losses)


    return E_entity, E_relation



# @tf.function
# def forward(E_entity, E_relation, batch_indices, training=False):
#     h_index, r_index, t_index = batch_indices[0], batch_indices[1], batch_indices[2]
#
#     h = tf.nn.embedding_lookup(E_entity, h_index)
#     r = tf.nn.embedding_lookup(E_relation, r_index)
#     t = tf.nn.embedding_lookup(E_entity, t_index)
#
#     return model([h, r, t], training=training)


compute_loss = tf.function(transe_loss)
compute_ranks = transe_ranks


for epoch in range(1, 10001):
    for step, (batch_h, batch_r, batch_t) in enumerate(
            tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).
                    shuffle(300000).batch(train_batch_size)):

        with tf.GradientTape() as tape:

            target_entity_type = ["head", "tail"][np.random.randint(0, 2)]
            if target_entity_type == "tail":
                batch_source = batch_h
                batch_target = batch_t
            else:
                batch_source = batch_t
                batch_target = batch_h

            with tf.GradientTape() as tape:
                E_entity, E_relation = encode(entity_embeddings)
                model = TransE(E_entity, E_relation)

                batch_neg_target = entity_negative_sampling(batch_source, batch_r, train_kg, target_entity_type,
                                                            filtered=False)

                embedded_neg_target = model.embed_norm_entities(batch_neg_target)
                embedded_target = model.embed_norm_entities(batch_target)

                translated = model([batch_source, batch_r], target_entity_type, training=True)

                pos_dis = compute_distance(translated, embedded_target, distance_norm)
                neg_dis = compute_distance(translated, embedded_neg_target, distance_norm)

                loss = compute_loss(pos_dis, neg_dis, margin=margin)

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        optimizer.apply_gradients(zip(grads, vars))

        if step % 20 == 0:
            print("epoch = {}\tstep = {}\tloss = {}".format(epoch, step, loss))

    if epoch % 10 == 0:

        normed_entity_embeddings = tf.math.l2_normalize(model.entity_embeddings, axis=-1)

        for target_entity_type in ["head", "tail"]:
            filter_list = filter_dict[target_entity_type]
            ranks = []
            for i, (batch_h, batch_r, batch_t) in enumerate(
                    tf.data.Dataset.from_tensor_slices((test_kg.h, test_kg.r, test_kg.t)).batch(test_batch_size)):

                batch_filter_list = filter_list[i*test_batch_size: (i+1)*test_batch_size]
                target_ranks = compute_ranks(batch_h, batch_r, batch_t, model, normed_entity_embeddings,
                                             target_entity_type, distance_norm=distance_norm, filter_list=batch_filter_list)
                ranks.append(target_ranks)

            ranks = tf.concat(ranks, axis=0)

            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            # hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])
            hits_1, hits_10, hits_100 = compute_hits(ranks, [1, 10, 100])
            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {:f}\tMRR = {:f}\t"
                "Hits@10 = {:f}\tHits@1 = {:f}\tHits@100 = {:f}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_10, hits_1, hits_100))

