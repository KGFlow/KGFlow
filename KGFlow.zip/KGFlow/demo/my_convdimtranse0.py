# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.model.convkb import ConvKB, convkb_ranks

from KGFlow.model.transe import TransE, compute_distance, transe_ranks
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.dataset.wn18 import WN18Dataset
from KGFlow.utils.sampling_utils import entity_negative_sampling
from KGFlow.metrics.ranks import compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
from KGFlow.metrics.ranks import compute_ranks_by_scores
from tensorflow.keras.layers import Conv1D, Dropout, BatchNormalization, Dense, Conv2D
from KGFlow.utils.rank_utils import compute_ranks, get_filter_dict


class ConvKGLayer(tf.keras.Model):
    def __init__(self, num_filters, activation=tf.nn.relu, drop_rate=0.0, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.conv2 = Conv1D(num_filters, 2, activation=activation, padding="same")
        self.conv3 = Conv1D(num_filters, 3, activation=activation)
        self.kernel = Dense(1)

    def call(self, inputs, training=None, mask=None):
        """

        :param inputs: [batch_embedded_h, batch_embedded_r, batch_embedded_t]
        :param training:
        :param mask:
        :return: a score Tensor which shape is (batch_size, 1)
        """
        h, r, t = inputs

        f = tf.stack([h, r, t], axis=-2)  # (batch, 3, dim)
        f = self.conv2(f)  # (batch, 3, num_filters)
        f2 = self.conv3(f)
        f2 = tf.tile(f2, [1, 3, 1])  # (batch, 3, num_filters)
        f = tf.concat([f, f2], axis=-1)

        return f


class ConvKG(tf.keras.Model):
    def __init__(self, entity_embeddings, relation_embeddings, num_filters, activation=tf.nn.relu,
                 drop_rate=0.0):
        super().__init__()
        self.entity_embeddings = entity_embeddings
        self.relation_embeddings = relation_embeddings

        self.convkg = ConvKGLayer(num_filters, activation, drop_rate)
        self.out_layer = Dense(1)

    def call(self, inputs, training=None, mask=None, compute_l2_loss=False):
        h_index, r_index, t_index = inputs

        h = tf.nn.embedding_lookup(self.entity_embeddings, h_index)
        r = tf.nn.embedding_lookup(self.relation_embeddings, r_index)
        t = tf.nn.embedding_lookup(self.entity_embeddings, t_index)

        f = self.convkg([h, r, t], training=training)    # (batch, 3, 2*num_filters)

        return f

    def decode(self, f):
        f = tf.reduce_sum(f, axis=-2)
        f = self.out_layer(f)
        return f

    def compute_loss(self, scores, labels, activation=tf.nn.softplus, l2_coe=0.0):
        loss = convkg_loss(scores, labels, activation)
        if l2_coe > 0.0:
            loss += tf.add_n([tf.nn.l2_loss(var) for var in self.trainable_variables if
                              "kernel" in var.name or "embedding" in var.name]) * l2_coe
        return loss


def convkg_loss(scores, labels, activation=tf.nn.softplus):
    """
    loss for ConvKG
    :param scores:
    :param labels: pos sample: +1, neg_sample: -1
    :param activation:
    :return: loss, shape: []
    """
    scores = tf.reshape(scores, [-1])
    labels = tf.reshape(tf.cast(labels, dtype=tf.float32), [-1])
    losses = activation(scores * labels)
    return tf.reduce_mean(losses)


# import pickle as pkl
# with open("data/mini_dataset.pkl", "rb") as f:
#     train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = pkl.load(f)

# train_kg, test_kg, valid_kg, entity2id, relation2id = WN18Dataset().load_data()
# train_kg, test_kg, valid_kg, entity2id, relation2id = FB15kDataset().load_data()
train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()


print(train_kg, test_kg, valid_kg)
# train_test_indices = np.concatenate([train_kg.graph_indices, test_kg.graph_indices], axis=-1)
# train_test_kg = kgf.KG(train_test_indices[0], train_test_indices[1], train_test_indices[2], entity2id, relation2id)


init_embedding = True
filter = True
filter_dict = get_filter_dict(test_kg, [train_kg, valid_kg]) if filter else None
num_filters = 16
train_n_batch = 100
train_batch_size = train_kg.num_triples // train_n_batch
# train_batch_size = 2000
test_batch_size = 10

learning_rate = 1e-2
drop_rate = 0.0
l2_coe = 0.0

optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

if init_embedding:
    entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
    # entity_embeddings = entity_init_embeddings
    # relation_embeddings = relation_init_embeddings
else:
    embedding_size = 32
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()

model = ConvKG(entity_embeddings, relation_embeddings, num_filters, drop_rate=drop_rate)
transe_model = TransE(entity_embeddings, relation_embeddings)


@tf.function
def transe_forward(inputs, target_entity_type, training=False):
    return transe_model(inputs, target_entity_type=target_entity_type, training=training)


@tf.function
def compute_transe_loss(batch_source, batch_r, batch_target, batch_neg_target, margin=0.5, distance_norm=1):
    embedded_neg_target = transe_model.embed_norm_entities(batch_neg_target)
    embedded_target = transe_model.embed_norm_entities(batch_target)

    translated = transe_forward([batch_source, batch_r], target_entity_type, training=True)

    pos_dis = compute_distance(translated, embedded_target, distance_norm)
    neg_dis = compute_distance(translated, embedded_neg_target, distance_norm)

    loss = transe_model.compute_loss(pos_dis, neg_dis, margin=margin, l2_coe=l2_coe)
    return loss


class Bilinear(tf.keras.Model):
    """
    Bilinear Model for DGI loss
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.dense = None
        self.bias = tf.Variable(0.0)

    def build(self, input_shapes):
        self.dense = tf.keras.layers.Dense(input_shapes[1][-1], use_bias=False)

    def call(self, inputs, training=None, mask=None, cache=None):
        a, b = inputs
        h = tf.reduce_sum(self.dense(a) * b, axis=-1) + self.bias
        return h


# Bilinear Model for DGI loss
bilinear_model = Bilinear()


def shuffle(x):
    perm_index = np.random.permutation(x.shape[0])
    x = tf.gather(x, perm_index)
    return x


def dgi_loss(batch_pos_indices, batch_neg_indices):

    pos_f = model(batch_pos_indices, training=True)
    neg_f = model(batch_neg_indices, training=True)

    # positive graph representations
    pos_graph_f = tf.nn.sigmoid(tf.reduce_mean(pos_f, axis=-2, keepdims=True))

    pos_logits = bilinear_model([pos_f, pos_graph_f], training=True)
    neg_logits = bilinear_model([neg_f, pos_graph_f], training=True)
    pos_logits = tf.reshape(pos_logits, [-1])
    neg_logits = tf.reshape(neg_logits, [-1])

    # pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(
    #     logits=pos_logits,
    #     labels=tf.ones_like(pos_logits)
    # )
    #
    # neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(
    #     logits=neg_logits,
    #     labels=tf.zeros_like(neg_logits)
    # )
    #
    # # DGI loss
    # loss = tf.reduce_mean(pos_losses + neg_losses)

    loss = tf.reduce_mean(tf.maximum(2.0, neg_logits - pos_logits))
    return loss



@tf.function
def forward(batch_indices, training=False):
    f = model(batch_indices, training=training)
    f = model.decode(f)
    return f


@tf.function
def compute_loss(pos_scores, neg_scores):

    loss = tf.nn.sigmoid_cross_entropy_with_logits(
        logits=tf.concat([pos_scores, neg_scores], axis=0),
        labels=tf.concat([tf.zeros_like(pos_scores), tf.ones_like(neg_scores)], axis=0)
    )
    loss = tf.reduce_mean(loss)
    # loss = model.compute_loss(tf.concat([pos_scores, neg_scores], axis=0),
    #                           tf.concat([tf.ones_like(pos_scores), -tf.ones_like(neg_scores)], axis=0),
    #                           activation=tf.nn.softplus, l2_coe=l2_coe)
    return loss


# compute_ranks = tf.function(compute_ranks)


for epoch in range(1, 100001):
    for step, (batch_h, batch_r, batch_t) in enumerate(
            tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).
                    shuffle(300000).batch(train_batch_size)):

        with tf.GradientTape() as tape:
            target_entity_type = ["head", "tail"][np.random.randint(0, 2)]
            if target_entity_type == "tail":
                batch_source = batch_h
                batch_target = batch_t
                batch_neg_target = entity_negative_sampling(batch_h, batch_r, train_kg, "tail")
                batch_neg_indices = [batch_h, batch_r, batch_neg_target]
            else:
                batch_source = batch_t
                batch_target = batch_h
                batch_neg_target = entity_negative_sampling(batch_t, batch_r, train_kg, "head")
                batch_neg_indices = [batch_neg_target, batch_r, batch_t]

            batch_pos_indices = [batch_h, batch_r, batch_t]
            pos_scores = forward(batch_pos_indices, training=True)
            neg_scores = forward(batch_neg_indices, training=True)

            p_loss = compute_loss(pos_scores, neg_scores)
            d_loss = dgi_loss(batch_pos_indices, batch_neg_indices)
            t_loss = compute_transe_loss(batch_source, batch_r, batch_target, batch_neg_target, 0.5, 1)

            loss = p_loss + d_loss + t_loss

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        optimizer.apply_gradients(zip(grads, vars))

        if step % 10 == 0:
            print("epoch = {}\tstep = {}\tp_loss = {:f}\td_loss = {:f}\tt_loss = {:f}\tloss = {:f}".format(epoch, step, p_loss, d_loss, t_loss, loss))

    # if epoch % 10 == 0:
    #     print("epoch = {}\tp_loss = {}\td_loss = {}\tloss = {}".format(epoch, p_loss, d_loss, loss))

    if epoch % 10 == 0:

        for target_entity_type in ["head", "tail"]:

            ranks = compute_ranks(test_kg, forward, target_entity_type, test_batch_size, filter_dict)
            # ranks = []
            # for (batch_h, batch_r, batch_t) in tf.data.Dataset.from_tensor_slices(
            #         (test_kg.h, test_kg.r, test_kg.t)).batch(test_batch_size):
            #     target_ranks = compute_ranks(batch_h, batch_r, batch_t, test_kg.num_entities, forward, target_entity_type)
            #     ranks.append(target_ranks)
            #
            # ranks = tf.concat(ranks, axis=0)

            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            # hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])
            hits_1, hits_10, hits_100 = compute_hits(ranks, [1, 10, 100])
            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {:f}\tMRR = {:f}\t"
                "Hits@10 = {:f}\tHits@1 = {:f}\tHits@100 = {:f}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_10, hits_1, hits_100))
