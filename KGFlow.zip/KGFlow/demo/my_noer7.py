# coding=utf-8
import os

os.environ["CUDA_VISIBLE_DEVICES"] = "5"
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
import tensorflow as tf
from tensorflow import keras
import numpy as np
import KGFlow as kgf
from KGFlow.model.convkb import ConvKB, convkb_ranks, ConvKBLayer, convkb_loss
from KGFlow.dataset.fb15k import FB15kDataset, FB15k237Dataset
from KGFlow.dataset.wn18 import WN18Dataset, WN18RRDataset
from KGFlow.metrics.ranks import compute_hits, compute_mean_rank, compute_mean_reciprocal_rank
from KGFlow.metrics.ranks import compute_ranks_by_scores
from KGFlow.utils.rank_utils import get_filter_dict, compute_ranks
from KGFlow.utils.sampling_utils import entity_negative_sampling, EntityNegativeSampler
from tensorflow.keras.layers import Conv1D, Dropout, BatchNormalization, Dense, Conv2D
import collections

# train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = WN18RRDataset().load_data()
train_kg, test_kg, valid_kg, entity2id, relation2id, entity_init_embeddings, relation_init_embeddings = FB15k237Dataset().load_data()

print(train_kg)
print(test_kg)
print(len(entity2id))
print(len(relation2id))

init_embedding = False
num_filters = 10

drop_rate = 0.3
l2_coe = 1e-4

train_n_batch = 100
train_batch_size = train_kg.num_triples // train_n_batch

# train_batch_size = 256
test_batch_size = 10
learning_rate = 1e-3

num_neg = 10
train_filtered = False
use_bn = False

filter = True
filter_dict = get_filter_dict(test_kg, [train_kg, valid_kg]) if filter else None

# optimizer = keras.optimizers.RMSprop(learning_rate=learning_rate)
# optimizer = keras.optimizers.SGD(learning_rate=learning_rate)
optimizer = keras.optimizers.Adam(learning_rate=learning_rate)

if init_embedding:
    embedding_size = 100
    entity_embeddings = tf.Variable(entity_init_embeddings, name="entity_embeddings")
    relation_embeddings = tf.Variable(relation_init_embeddings, name="relation_embeddings")
else:
    embedding_size = 32
    E = kgf.RandomInitEmbeddings(train_kg.num_entities, train_kg.num_relations, embedding_size)
    entity_embeddings, relation_embeddings = E()


model = ConvKBLayer(num_filters, activation=tf.nn.relu, drop_rate=drop_rate)
sampler = EntityNegativeSampler(train_kg)


class Bilinear(tf.keras.Model):
    """
    Bilinear Model for DGI loss
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.dense = None
        self.bias = tf.Variable(0.0)

    def build(self, input_shapes):
        self.dense = tf.keras.layers.Dense(input_shapes[1][-1], use_bias=False)

    def call(self, inputs, training=None, mask=None, cache=None):
        a, b = inputs
        h = tf.reduce_sum(self.dense(a) * b, axis=-1) + self.bias
        return h


# Bilinear Model for DGI loss
bilinear_model = Bilinear()

dense_r = tf.Variable(tf.random.truncated_normal([train_kg.num_relations, embedding_size, 20], stddev=0.01))



def shuffle(x):
    perm_index = np.random.permutation(x.shape[0])
    x = tf.gather(x, perm_index)
    return x



def encode(E_entity):
    h_index, r_index, t_index = train_kg.graph_indices

    E_all = E_entity @ dense_r
    E_all = tf.nn.l2_normalize(E_all)

    # E_l2 = tf.nn.l2_normalize(E_entity)
    h = tf.gather_nd(E_all, tf.stack([r_index, h_index], axis=-1))
    t = tf.gather_nd(E_all, tf.stack([r_index, t_index], axis=-1))

    r = t - h
    E_r = tf.math.unsorted_segment_mean(r, r_index, train_kg.num_relations)

    rr = tf.nn.embedding_lookup(E_r, r_index)
    tt = h + rr
    hh = t - rr

    E_e = tf.math.unsorted_segment_mean(tf.concat([hh, tt], axis=0),
                                        tf.concat([h_index, t_index], axis=0), train_kg.num_entities)

    # E_e = (E_e + E_l2) / 2

    pos_logits = bilinear_model([E_entity, E_e], training=True)
    neg_logits = bilinear_model([shuffle(E_entity), E_e], training=True)

    pos_losses = tf.nn.softplus(pos_logits)
    neg_losses = tf.nn.softplus(neg_logits)

    dgi_loss = tf.reduce_mean(neg_losses - pos_losses)
    # pos_logits = bilinear_model([E_l2, E_e], training=True)
    # neg_logits = bilinear_model([shuffle(E_l2), E_e], training=True)
    # pos_logits = tf.reduce_sum(E_l2 * E_e, axis=-1)
    # neg_logits = tf.reduce_sum(shuffle(E_l2) * E_e, axis=-1)

    # pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(
    #     logits=pos_logits,
    #     labels=tf.ones_like(pos_logits)
    # )
    #
    # neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(
    #     logits=neg_logits,
    #     labels=tf.zeros_like(neg_logits)
    # )
    #
    # # DGI loss
    # dgi_loss = tf.reduce_mean(pos_losses + neg_losses)

    # dgi_loss = tf.math.maximum(0.0, neg_logits - pos_logits)
    # dgi_loss = tf.reduce_mean(dgi_loss)
    # dgi_loss = 0.0

    return E_e, E_r, dgi_loss



@tf.function
def forward(E_entity, E_relation, batch_indices, training=False):
    h_index, r_index, t_index = batch_indices[0], batch_indices[1], batch_indices[2]

    h = tf.nn.embedding_lookup(E_entity, h_index)
    r = tf.nn.embedding_lookup(E_relation, r_index)
    t = tf.nn.embedding_lookup(E_entity, t_index)

    return model([h, r, t], training=training)


# @tf.function
# def dgi_loss(E_entity, E_relation, batch_indices, training=False):
#     h_index, r_index, t_index = batch_indices[0], batch_indices[1], batch_indices[2]
#
#     h = tf.nn.embedding_lookup(E_entity, h_index)
#     r = tf.nn.embedding_lookup(E_relation, r_index)
#     t = tf.nn.embedding_lookup(E_entity, t_index)
#
#     return model([h, r, t], training=training)


@tf.function
def compute_loss(pos_scores, neg_scores):
    # pos_losses = tf.nn.sigmoid_cross_entropy_with_logits(tf.zeros_like(pos_scores), pos_scores)
    # neg_losses = tf.nn.sigmoid_cross_entropy_with_logits(tf.ones_like(neg_scores), neg_scores)
    # pos_loss = tf.reduce_mean(pos_losses)
    # neg_loss = tf.reduce_mean(neg_losses)
    pos_loss = convkb_loss(pos_scores, tf.ones_like(pos_scores), activation=tf.nn.softplus)
    neg_loss = convkb_loss(neg_scores, -tf.ones_like(neg_scores), activation=tf.nn.softplus)

    loss = pos_loss + neg_loss
    return loss


# compute_ranks = tf.function(convkg_ranks)
# allllll_ranks = []
ee = entity_embeddings.value()

for epoch in range(1, 10001):
    for step, (batch_h, batch_r, batch_t) in enumerate(
            tf.data.Dataset.from_tensor_slices((train_kg.h, train_kg.r, train_kg.t)).
                    shuffle(300000).batch(train_batch_size)):

        with tf.GradientTape() as tape:

            batch_neg_indices = sampler.indices_sampling(batch_h, batch_r, batch_t, num_neg=num_neg,
                                                         filtered=train_filtered)

            E_e, E_r, d_loss = encode(entity_embeddings)
            # E_e, E_r, d_loss = gnn(entity_embeddings)
            pos_scores = forward(E_e, E_r, [batch_h, batch_r, batch_t], training=True)
            neg_scores = forward(E_e, E_r, batch_neg_indices, training=True)

            loss = compute_loss(pos_scores, neg_scores) + d_loss

            # batch_entity = list(set(list(tf.concat([batch_neg_indices[0], batch_neg_indices[2]], axis=-1).numpy())))
            # batch_relation = list(set(list(batch_r.numpy())))
            # l2_loss = tf.nn.l2_loss(tf.nn.embedding_lookup(E_e, batch_h)) + \
            #           tf.nn.l2_loss(tf.nn.embedding_lookup(E_r, batch_r)) + \
            #           tf.nn.l2_loss(tf.nn.embedding_lookup(E_e, batch_t))
            # # E_l2_loss = [tf.nn.l2_loss(batch_relation), tf.nn.l2_loss(batch_entity)]
            # #
            # l2_loss = tf.add_n([tf.nn.l2_loss(var) for var in tape.watched_variables() if "kernel" in var.name or "embedding" in var.name])
            # l2_loss *= l2_coe
            # loss += l2_loss

        vars = tape.watched_variables()
        grads = tape.gradient(loss, vars)
        optimizer.apply_gradients(zip(grads, vars))

        if step % 20 == 0:
            print("epoch = {}\tstep = {}\tloss = {}\td_loss = {}".format(epoch, step, loss, d_loss))

    if epoch % 20 == 0:

        for target_entity_type in ["head", "tail"]:
            ranks = compute_ranks(test_kg, lambda x: forward(E_e, E_r, x), target_entity_type, test_batch_size,
                                  filter_dict)
            # allllll_ranks.append(ranks)
            mean_rank = compute_mean_rank(ranks)
            mrr = compute_mean_reciprocal_rank(ranks)
            # hits_1, hits_3, hits_10, hits_100, hits_1000 = compute_hits(ranks, [1, 3, 10, 100, 1000])
            hits_1, hits_10, hits_100 = compute_hits(ranks, [1, 10, 100])
            print(
                "epoch = {}\ttarget_entity_type = {}\tMR = {:f}\tMRR = {:f}\t"
                "Hits@10 = {:f}\tHits@1 = {:f}\tHits@100 = {:f}".format(
                    epoch, target_entity_type, mean_rank, mrr,
                    hits_10, hits_1, hits_100))
    #
    # if epoch == 50:
    #     import pickle as pkl
    #     with open("data/all_ranks.pkl", "wb") as f:
    #         pkl.dump(allllll_ranks, f)
