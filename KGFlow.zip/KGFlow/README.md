# KGFlow

An Open Source KnowLedge Graph Framework for TensorFlow 2.x