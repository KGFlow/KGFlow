from KGFlow.model.transe import TransE
from KGFlow.model.gat import GAT
from KGFlow.model.gat import KBGAT