from KGFlow.metrics.distmult import distmult
from KGFlow.metrics.convkb import ConvKBLayer
from KGFlow.metrics.ranks import *
