from KGFlow.dataset import wn18
from KGFlow.dataset import fb15k
from KGFlow.dataset import kinship
